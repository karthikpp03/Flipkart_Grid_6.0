function displayCameras() {
    const cameras = [];
    const videoElements = [
      document.getElementById('video1'),
      document.getElementById('video2'),
      document.getElementById('video3')
    ];
  
    // Get the list of video input devices (cameras)
    navigator.mediaDevices.enumerateDevices()
      .then(devices => {
        devices.forEach(device => {
          if (device.kind === 'videoinput') {
            cameras.push(device);
          }
        });
  
        // Start cameras based on how many are available
        if (cameras.length > 0) {
          for (let i = 0; i < cameras.length && i < videoElements.length; i++) {
            videoElements[i].style.display = "block";  // Show the video element
            startCamera(i, videoElements[i]);
          }
        } else {
          console.log('No camera found');
        }
      })
      .catch(err => {
        console.log('Error getting devices: ', err);
      });
  
    // Function to start streaming from a specific camera
    function startCamera(cameraIndex, videoElement) {
      const camera = cameras[cameraIndex];
      navigator.mediaDevices.getUserMedia({
        video: {
          deviceId: { exact: camera.deviceId }
        }
      })
      .then(stream => {
        videoElement.srcObject = stream;
      })
      .catch(err => {
        console.log('Error accessing camera: ', err);
      });
    }
}