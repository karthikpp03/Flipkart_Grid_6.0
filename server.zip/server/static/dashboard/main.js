var a = 0;

async function fetchData() {
    try {
        const response = await fetch('http://192.168.122.176:5000/getdashboarddata');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();

        // Get and insert the real images
        const v1 = document.getElementById('video-1');
        const v2 = document.getElementById('video-2');
        const v3 = document.getElementById('video-3');

        const img1 = document.createElement('img');
        const img2 = document.createElement('img');
        const img3 = document.createElement('img');

        img1.src = `data:image/jpeg;base64,${data.RealImages[0].ImageData}`;
        img2.src = `data:image/jpeg;base64,${data.RealImages[1].ImageData}`;
        img3.src = `data:image/jpeg;base64,${data.RealImages[2].ImageData}`;

        if (a !== 0) {
            if (v1.firstChild) v1.removeChild(v1.firstChild);
            if (v2.firstChild) v2.removeChild(v2.firstChild);
            if (v3.firstChild) v3.removeChild(v3.firstChild);
        }

        v1.appendChild(img1);
        v2.appendChild(img2);
        v3.appendChild(img3);

        // Get and insert the product image
        const v4 = document.getElementById("productImage");
        const img4 = document.createElement('img');

        img4.src = `data:image/jpeg;base64,${data.objectImage[0].ImageData}`;

        if (a !== 0) {
            v4.removeChild(v4.firstChild);
        } else {
            a = 1;  // Set `a` to 1 after the first iteration
        }

        v4.appendChild(img4);


        // 

    } catch (error) {
        console.error('There was a problem with the fetch operation:', error);
    }
}

setInterval(fetchData, 5000);
fetchData();