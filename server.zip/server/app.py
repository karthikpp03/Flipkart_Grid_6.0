from flask import Flask, render_template, jsonify, request
from pymongo import MongoClient
from bson.json_util import dumps
import base64
import os

# Connect to the MongoDB database
client = MongoClient("mongodb://localhost:27017/")

app = Flask(__name__)

# -------- HTML rendering routes --------
@app.route('/')
def deshboard():
    return render_template('dashboard/main.html')

@app.route('/productdetails')
def productdetails():
    return render_template('productDetails/main.html')

@app.route('/about')
def about():
    return render_template('about/main.html')

# -------- Utility function to encode images to Base64 --------
def encode_image_to_base64(image_path):
    try:
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')
    except FileNotFoundError:
        return None  # Return None if the image file is not found

# -------- API Routes --------

# Send sorting value to hardware
@app.route('/sortingValue', methods=['GET'])
def sendSortingValue():
    db = client['hardWare']
    collection = db['value']
    
    try:
        # Fetch the sorting value
        documents = collection.find({}, {'_id': 0, 'value': 1})
        json_data = dumps(documents)

        # Reset the sorting value to 0
        collection.update_one({'value': {'$in': [-1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}}, {'$set': {'value': 0}})
        
        return json_data, 200, {'Content-Type': 'application/json'}

    except Exception as e:
        return jsonify(message="An error occurred", error=str(e)), 500

# Dashboard details sender
@app.route('/getdashboarddata', methods=['GET'])
def GetDashboardData():
    db = client['liveProduct']
    collection = db['productDetails']
    
    # Fetch product data
    productData = collection.find_one({}, {"_id": 0, "detail": 1})
    
    if productData:
        # Load deducted images
        image_paths = [
            "/home/sridhar/myData/college projects/flipkart-6.0/main/finalCode/server/static/deductedImages/image-0.jpg", 
            "/home/sridhar/myData/college projects/flipkart-6.0/main/finalCode/server/static/deductedImages/image-1.jpg", 
            "/home/sridhar/myData/college projects/flipkart-6.0/main/finalCode/server/static/deductedImages/image-2.jpg"
        ]
        
        # Initialize RealImages list
        productData['RealImages'] = []
        
        # Encode each image and add to RealImages
        for i, image_path in enumerate(image_paths):
            encoded_image = encode_image_to_base64(image_path)
            if encoded_image:  # Add only if image was successfully encoded
                productData['RealImages'].append({"ImageData": encoded_image, "ImageName": f"image_{i + 1}"})

        # Load object image based on product name
        product_name = productData['detail'].get('ProductName', "")
        
        if product_name:
            imagePath = os.path.join("/home/sridhar/myData/college projects/flipkart-6.0/main/finalCode/server/static/productImages", product_name)
        else:
            imagePath = "/home/sridhar/myData/college projects/flipkart-6.0/main/finalCode/server/static/productImages/image.jpg"
        
        # Add object image
        encoded_object_image = encode_image_to_base64(imagePath)
        if encoded_object_image:
            productData['objectImage'] = [{"ImageData": encoded_object_image, "ImageName": "productImage"}]

        # Return the data as JSON
        json_data = dumps(productData)
        return json_data, 200

    else:
        return jsonify({"error": "No product found"}), 404
    
# Get the action from the hardware
@app.route('/getaction', methods=['GET'])
def Getaction():
    value = request.args.get('value')
    
    if value is None:
        return jsonify({"error": "Missing 'value' parameter"}), 400
    
    if value not in ['true', 'false']:
        return jsonify({"error": "Invalid 'value'. It should be 'true' or 'false'"}), 400
    
    try:
        db = client['action']
        collection = db['data']
        collection.update_one(
            {"value": {'$in': ["true", "false"]}},
            {'$set': {"value": value}}
        )
        return jsonify({"message": "Update successful"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
